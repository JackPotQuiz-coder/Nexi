import 'package:flutter/material.dart';

import '../features/category/category_screen.dart';
import '../features/gameplay/gameplay_screen.dart';
import '../features/home/home_screen.dart';
import '../features/result/result_screen.dart';
import '../features/splash/splash_screen.dart';
import '../pages/leaderboard/leaderboard_screen.dart';
import '../pages/profile/profile_screen.dart';
import '../pages/settings/settings_screen.dart';
import '../pages/placeholder_page.dart';

/// Centralized route registry for the NEXIRA application.
///
/// This file defines named routes only and keeps navigation concerns separated
/// from pages, business logic, and UI implementation.
class AppRoutes {
  AppRoutes._();

  static const String splash = '/splash';
  static const String home = '/home';
  static const String battle = '/battle';
  static const String category = '/category';
  static const String result = '/result';
  static const String profile = '/profile';
  static const String leaderboard = '/leaderboard';
  static const String settings = '/settings';

  static const String initial = splash;

  static final Map<String, String> moduleRoutes = {
    'splash': splash,
    'home': home,
    'battle': battle,
    'category': category,
    'result': result,
    'profile': profile,
    'leaderboard': leaderboard,
    'settings': settings,
  };

  static Route<dynamic> onGenerateRoute(RouteSettings routeSettings) {
    final routeName = routeSettings.name ?? initial;

    switch (routeName) {
      case splash:
        return _buildRoute(routeSettings, splash, const SplashScreen());
      case home:
        return _buildRoute(routeSettings, home, const HomeScreen());
      case category:
        return _buildRoute(routeSettings, category, const CategoryScreen());
      case battle:
        final categoryId = routeSettings.arguments is String ? routeSettings.arguments as String : null;
        return _buildRoute(routeSettings, battle, GameplayScreen(categoryId: categoryId));
      case result:
        final categoryId = routeSettings.arguments is String ? routeSettings.arguments as String : null;
        return _buildRoute(routeSettings, result, ResultScreen(categoryId: categoryId));
      case profile:
        return _buildRoute(routeSettings, profile, const ProfileScreen());
      case leaderboard:
        return _buildRoute(routeSettings, leaderboard, const LeaderboardScreen());
      case settings:
        return _buildRoute(routeSettings, settings, const SettingsScreen());
      default:
        return _buildRoute(routeSettings, initial, const PlaceholderPage(title: 'Splash'));
    }
  }

  static Route<dynamic> _buildRoute(RouteSettings settings, String routeName, Widget page) {
    return MaterialPageRoute<dynamic>(
      settings: RouteSettings(name: routeName),
      builder: (_) => page,
    );
  }
}
