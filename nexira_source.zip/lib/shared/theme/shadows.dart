import 'package:flutter/material.dart';

import 'colors.dart';

abstract final class NexiraShadows {
  static const BoxShadow neonGlow = BoxShadow(
    color: NexiraColors.accent,
    blurRadius: 18,
    spreadRadius: 0,
    offset: Offset(0, 0),
  );

  static const BoxShadow neonGlowSoft = BoxShadow(
    color: NexiraColors.primary,
    blurRadius: 12,
    spreadRadius: -2,
    offset: Offset(0, 4),
  );

  static const BoxShadow cardShadow = BoxShadow(
    color: Color(0x66050816),
    blurRadius: 20,
    spreadRadius: 0,
    offset: Offset(0, 10),
  );
}
