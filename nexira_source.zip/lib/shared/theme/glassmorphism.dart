import 'package:flutter/material.dart';

import 'colors.dart';

abstract final class NexiraGlassmorphism {
  static BoxDecoration cardDecoration({Color? borderColor, double opacity = 0.2}) {
    return BoxDecoration(
      color: NexiraColors.surface.withOpacity(opacity),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: borderColor ?? NexiraColors.border, width: 1.2),
      boxShadow: const [
        BoxShadow(
          color: Color(0x33050816),
          blurRadius: 20,
          offset: Offset(0, 8),
        ),
      ],
    );
  }
}
