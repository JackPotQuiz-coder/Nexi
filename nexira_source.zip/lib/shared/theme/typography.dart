import 'package:flutter/material.dart';

abstract final class NexiraTypography {
  static const String fontFamily = 'Roboto';
  static const String headingFontFamily = 'Orbitron';
  static const String numberFontFamily = 'Oswald';
  static const String fontPackage = 'google_fonts';

  static const TextStyle display = TextStyle(
    fontSize: 56,
    fontWeight: FontWeight.w700,
    letterSpacing: 1.2,
    height: 1.1,
    fontFamily: headingFontFamily,
  );

  static const TextStyle headline = TextStyle(
    fontSize: 32,
    fontWeight: FontWeight.w600,
    letterSpacing: 0.8,
    height: 1.2,
    fontFamily: headingFontFamily,
  );

  static const TextStyle title = TextStyle(
    fontSize: 22,
    fontWeight: FontWeight.w600,
    height: 1.3,
    fontFamily: headingFontFamily,
  );

  static const TextStyle body = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w400,
    height: 1.5,
    fontFamily: fontFamily,
  );

  static const TextStyle label = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.w500,
    height: 1.4,
    fontFamily: fontFamily,
  );

  static const TextStyle caption = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.w400,
    height: 1.3,
    fontFamily: fontFamily,
  );

  static TextTheme get textTheme => const TextTheme(
        displayLarge: display,
        headlineLarge: headline,
        titleLarge: title,
        bodyLarge: body,
        bodyMedium: body,
        labelLarge: label,
        bodySmall: caption,
      );
}
