import 'package:flutter/material.dart';

import 'colors.dart';

abstract final class NexiraGradients {
  static const LinearGradient primary = LinearGradient(
    colors: [NexiraColors.primary, NexiraColors.accent],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient surface = LinearGradient(
    colors: [NexiraColors.surface, NexiraColors.surfaceElevated],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
}
