import 'package:flutter/material.dart';

abstract final class NexiraColors {
  static const Color primary = Color(0xFF8028FF);
  static const Color accent = Color(0xFF00B2FF);
  static const Color neonGreen = Color(0xFF00FF88);
  static const Color hotPink = Color(0xFFFF0082);
  static const Color success = neonGreen;
  static const Color warning = Color(0xFFFFC107);
  static const Color danger = hotPink;

  static const Color background = Color(0xFF0D102A);
  static const Color surface = Color(0x99161B3D);
  static const Color surfaceElevated = Color(0xCC1B2250);
  static const Color border = Color(0x665D8BFF);

  static const Color textPrimary = Color(0xFFE0E0DC);
  static const Color textSecondary = Color(0xFFA6B0C8);
  static const Color textDisabled = Color(0xFF64748B);

  static const Color overlay = Color(0x66050816);
  static const Color shimmer = Color(0x1AFFFFFF);
}
