import 'package:flutter/material.dart';

import 'colors.dart';

extension NexiraThemeExtensions on ThemeData {
  Color get neonPrimary => NexiraColors.primary;
  Color get neonAccent => NexiraColors.accent;
  Color get surfaceGlow => NexiraColors.surfaceElevated;
  Color get textPrimaryColor => NexiraColors.textPrimary;
  Color get textSecondaryColor => NexiraColors.textSecondary;
}
