import 'package:flutter/material.dart';

import '../../routes/app_routes.dart';
import '../theme/colors.dart';
import '../theme/radius.dart';
import 'glass_card.dart';

class NexiraBottomNavBar extends NeonBottomNavBar {
  const NexiraBottomNavBar({super.key, required super.activeRoute});
}

class NeonBottomNavBar extends StatelessWidget {
  const NeonBottomNavBar({super.key, required this.activeRoute});

  final String activeRoute;

  @override
  Widget build(BuildContext context) {
    const items = <({String label, IconData icon, String route})>[
      (label: 'Home', icon: Icons.home_rounded, route: AppRoutes.home),
      (label: 'Profile', icon: Icons.person_rounded, route: AppRoutes.profile),
      (label: 'Ranks', icon: Icons.emoji_events_rounded, route: AppRoutes.leaderboard),
      (label: 'Settings', icon: Icons.settings_rounded, route: AppRoutes.settings),
    ];

    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      child: Row(
        children: items.map((item) {
          final isActive = item.route == activeRoute;
          return Expanded(
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              margin: const EdgeInsets.symmetric(horizontal: 2),
              decoration: BoxDecoration(
                color: isActive ? NexiraColors.accent.withValues(alpha: 0.18) : Colors.transparent,
                borderRadius: NexiraRadius.medium,
              ),
              child: InkWell(
                onTap: () => Navigator.of(context).pushNamed(item.route),
                borderRadius: NexiraRadius.medium,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        item.icon,
                        color: isActive ? NexiraColors.neonGreen : NexiraColors.textSecondary,
                        size: isActive ? 26 : 24,
                      ),
                      const SizedBox(height: 3),
                      Text(
                        item.label,
                        style: TextStyle(
                          color: isActive ? NexiraColors.neonGreen : NexiraColors.textSecondary,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.3,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}