import 'package:flutter/material.dart';

import '../theme/colors.dart';

class NeonLoader extends StatelessWidget {
  const NeonLoader({super.key, this.size = 42});

  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CircularProgressIndicator(
        strokeWidth: 3,
        valueColor: const AlwaysStoppedAnimation<Color>(NexiraColors.neonGreen),
        backgroundColor: NexiraColors.primary.withValues(alpha: 0.24),
        semanticsLabel: 'Loading',
      ),
    );
  }
}