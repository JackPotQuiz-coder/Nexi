import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../theme/colors.dart';
import '../theme/radius.dart';
import '../theme/spacing.dart';
import '../theme/typography.dart';

class NeonAppBar extends StatelessWidget implements PreferredSizeWidget {
  const NeonAppBar({
    super.key,
    this.title,
    this.leading,
    this.actions,
    this.centerTitle = true,
    this.automaticallyImplyLeading = true,
    this.bottom,
    this.onBackPressed,
  });

  final Widget? title;
  final Widget? leading;
  final List<Widget>? actions;
  final bool centerTitle;
  final bool automaticallyImplyLeading;
  final PreferredSizeWidget? bottom;
  final VoidCallback? onBackPressed;

  @override
  Size get preferredSize {
    final bottomHeight = bottom?.preferredSize.height ?? 0;
    return Size.fromHeight(kToolbarHeight + bottomHeight);
  }

  @override
  Widget build(BuildContext context) {
    final themeExtension = Theme.of(context).extension<NexiraThemeData>();
    final backgroundColor = themeExtension?.backgroundColor ?? NexiraColors.background;
    final surfaceColor = themeExtension?.surfaceColor ?? NexiraColors.surface;
    final borderColor = themeExtension?.borderColor ?? NexiraColors.border;
    final textColor = themeExtension?.textPrimaryColor ?? NexiraColors.textPrimary;
    final radius = themeExtension?.radius ?? NexiraRadius.large;
    final spacing = themeExtension?.spacing ?? NexiraSpacing.m;

    final effectiveLeading = leading ??
        (automaticallyImplyLeading
            ? IconButton(
                onPressed: onBackPressed ?? () => Navigator.maybePop(context),
                icon: const Icon(Icons.arrow_back_rounded),
              )
            : null);

    return AppBar(
      title: title == null
          ? null
          : DefaultTextStyle(
              style: NexiraTypography.title.copyWith(color: textColor),
              child: title!,
            ),
      leading: effectiveLeading,
      actions: actions,
      centerTitle: centerTitle,
      elevation: 0,
      backgroundColor: backgroundColor,
      foregroundColor: textColor,
      surfaceTintColor: Colors.transparent,
      automaticallyImplyLeading: false,
      toolbarHeight: kToolbarHeight,
      shape: RoundedRectangleBorder(borderRadius: radius),
      bottom: bottom,
      flexibleSpace: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [backgroundColor, surfaceColor],
          ),
          border: Border(bottom: BorderSide(color: borderColor.withOpacity(0.5), width: 1)),
        ),
      ),
      titleSpacing: spacing,
    );
  }
}
