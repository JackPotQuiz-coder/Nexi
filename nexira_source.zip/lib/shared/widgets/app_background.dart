import 'package:flutter/material.dart';

import '../theme/colors.dart';
import '../theme/durations.dart';
import '../theme/spacing.dart';
import '../theme/app_theme.dart';

class AppBackground extends StatelessWidget {
  const AppBackground({
    super.key,
    required this.child,
    this.padding,
    this.overlay,
    this.showDecorations = true,
  });

  final Widget child;
  final EdgeInsetsGeometry? padding;
  final Widget? overlay;
  final bool showDecorations;

  @override
  Widget build(BuildContext context) {
    final themeExtension = Theme.of(context).extension<NexiraThemeData>();
    final backgroundColor =
        themeExtension?.backgroundColor ?? NexiraColors.background;
    final spacing = themeExtension?.spacing ?? NexiraSpacing.m;

    return AnimatedContainer(
      duration: NexiraDurations.normal,
      width: double.infinity,
      height: double.infinity,
      decoration: BoxDecoration(color: backgroundColor),
      child: Stack(
        children: [
          if (showDecorations) ...[
            const Positioned.fill(child: TunnelBackground()),
          ],
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [const Color(0x33050816), const Color(0x661B2250)],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: padding ?? EdgeInsets.all(spacing),
              child: child,
            ),
          ),
          if (overlay != null) overlay!,
        ],
      ),
    );
  }
}

class TunnelBackground extends StatelessWidget {
  const TunnelBackground({super.key, this.child});

  final Widget? child;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(
          child: IgnorePointer(
            child: Image.asset(
              'assets/backgrounds/tunnel_main.png',
              fit: BoxFit.cover,
              filterQuality: FilterQuality.high,
              width: double.infinity,
              height: double.infinity,
              alignment: Alignment.center,
            ),
          ),
        ),
        if (child != null) Positioned.fill(child: child!),
      ],
    );
  }
}
