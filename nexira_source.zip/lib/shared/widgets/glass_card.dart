import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../theme/colors.dart';
import '../theme/radius.dart';
import '../theme/spacing.dart';

class NeonCard extends StatelessWidget {
  const NeonCard({
    super.key,
    required this.child,
    this.padding,
    this.margin,
    this.borderRadius,
    this.width,
    this.height,
    this.onTap,
    this.borderColor,
    this.opacity = 0.82,
  });

  final Widget child;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final BorderRadiusGeometry? borderRadius;
  final double? width;
  final double? height;
  final VoidCallback? onTap;
  final Color? borderColor;
  final double opacity;

  @override
  Widget build(BuildContext context) {
    final themeExtension = Theme.of(context).extension<NexiraThemeData>();
    final surfaceColor = themeExtension?.surfaceColor ?? NexiraColors.surface;
    final borderColorValue = borderColor ?? themeExtension?.borderColor ?? NexiraColors.border;
    final radius = borderRadius ?? themeExtension?.radius ?? NexiraRadius.large;
    final spacing = themeExtension?.spacing ?? NexiraSpacing.m;
    final shadow = themeExtension?.shadow ?? const BoxShadow(color: Color(0x33050816), blurRadius: 20, offset: Offset(0, 8));

    final card = ClipRRect(
      borderRadius: radius,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          width: width,
          height: height,
          margin: margin,
          padding: padding ?? EdgeInsets.all(spacing),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [surfaceColor.withValues(alpha: opacity), const Color(0x661B2250)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: radius,
            border: Border.all(color: borderColorValue.withValues(alpha: 0.9), width: 1.1),
            boxShadow: [
              shadow,
              BoxShadow(color: NexiraColors.primary.withValues(alpha: 0.12), blurRadius: 22),
              BoxShadow(color: NexiraColors.accent.withValues(alpha: 0.12), blurRadius: 18),
            ],
          ),
          child: child,
        ),
      ),
    );

    if (onTap == null) {
      return card;
    }

    return ClipRRect(
      borderRadius: radius,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: radius as BorderRadius?,
          child: card,
        ),
      ),
    );
  }
}

class GlassCard extends NeonCard {
  const GlassCard({
    super.key,
    required super.child,
    super.padding,
    super.margin,
    super.borderRadius,
    super.width,
    super.height,
    super.onTap,
    super.borderColor,
    super.opacity,
  });
}
