import 'dart:convert';

import 'package:flutter/services.dart';

import '../core/models/question_model.dart';

class QuestionRepository {
  QuestionRepository({AssetBundle? assetBundle})
      : _assetBundle = assetBundle ?? rootBundle;

  final AssetBundle _assetBundle;

  Future<List<QuestionModel>> loadQuestions() async {
    final raw = await _assetBundle.loadString('assets/questions/seed_questions.json');
    final decoded = json.decode(raw) as List<dynamic>;
    return decoded
        .map((item) => QuestionModel.fromJson(item as Map<String, dynamic>))
        .toList();
  }

  Future<List<QuestionModel>> filterByCategory(String categoryId) async {
    final questions = await loadQuestions();
    return questions.where((question) => question.categoryId == categoryId).toList();
  }

  Future<QuestionModel?> getQuestionById(String id) async {
    final questions = await loadQuestions();
    return questions.where((question) => question.id == id).cast<QuestionModel?>().firstOrNull;
  }
}

extension _FirstOrNullExtension<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
