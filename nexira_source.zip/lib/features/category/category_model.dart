import 'package:flutter/material.dart';

class CategoryModel {
  const CategoryModel({
    required this.id,
    required this.title,
    required this.description,
    required this.icon,
    required this.color,
  });

  final String id;
  final String title;
  final String description;
  final IconData icon;
  final Color color;

  static List<CategoryModel> get mockCategories => [
        const CategoryModel(
          id: 'general-knowledge',
          title: 'General Knowledge',
          description: 'Wide-ranging questions for quick mental sparks.',
          icon: Icons.psychology_alt_rounded,
          color: Color(0xFF8B5CF6),
        ),
        const CategoryModel(
          id: 'science',
          title: 'Science',
          description: 'Explore discoveries, systems, and the natural world.',
          icon: Icons.science_rounded,
          color: Color(0xFF00E5FF),
        ),
        const CategoryModel(
          id: 'technology',
          title: 'Technology',
          description: 'Dive into tools, systems, and modern innovation.',
          icon: Icons.computer_rounded,
          color: Color(0xFF39FF14),
        ),
        const CategoryModel(
          id: 'cars',
          title: 'Cars',
          description: 'Speed through questions about machines and motion.',
          icon: Icons.directions_car_rounded,
          color: Color(0xFFFFC107),
        ),
        const CategoryModel(
          id: 'space',
          title: 'Space',
          description: 'Journey through planets, stars, and the unknown.',
          icon: Icons.rocket_launch_rounded,
          color: Color(0xFFFF2D55),
        ),
        const CategoryModel(
          id: 'history',
          title: 'History',
          description: 'Revisit moments that shaped the world.',
          icon: Icons.history_edu_rounded,
          color: Color(0xFF8B5CF6),
        ),
        const CategoryModel(
          id: 'sports',
          title: 'Sports',
          description: 'Take on fast-paced challenges from the arena.',
          icon: Icons.sports_esports_rounded,
          color: Color(0xFF00E5FF),
        ),
        const CategoryModel(
          id: 'programming',
          title: 'Programming',
          description: 'Test your logic in a code-inspired arena.',
          icon: Icons.code_rounded,
          color: Color(0xFF39FF14),
        ),
      ];
}
