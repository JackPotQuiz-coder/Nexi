import 'package:flutter/material.dart';

import '../../routes/app_routes.dart';
import '../../shared/theme/colors.dart';
import '../../shared/theme/radius.dart';
import '../../shared/theme/spacing.dart';
import '../../shared/theme/typography.dart';
import '../../shared/widgets/app_background.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/neon_button.dart';
import '../../shared/widgets/neon_bottom_nav_bar.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.sizeOf(context).width;
    final isCompact = screenWidth < 640;

    return TunnelBackground(
      child: Scaffold(
        body: AppBackground(
          child: SafeArea(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(
                horizontal: isCompact ? NexiraSpacing.l : NexiraSpacing.xl,
                vertical: NexiraSpacing.l,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _PlayerHeader(),
                  SizedBox(height: NexiraSpacing.xl),
                  _PrimaryActionCard(),
                  SizedBox(height: NexiraSpacing.xl),
                  _ModeSection(),
                  SizedBox(height: NexiraSpacing.xl),
                  const NexiraBottomNavBar(activeRoute: AppRoutes.home),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _PlayerHeader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(20),
      child: Row(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [NexiraColors.primary, NexiraColors.accent],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: Border.all(
                color: NexiraColors.neonGreen.withValues(alpha: 0.55),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: NexiraColors.primary.withValues(alpha: 0.38),
                  blurRadius: 18,
                  spreadRadius: 1,
                ),
              ],
            ),
            alignment: Alignment.center,
            child: Text(
              'G',
              style: NexiraTypography.title.copyWith(
                color: NexiraColors.textPrimary,
              ),
            ),
          ),
          const SizedBox(width: NexiraSpacing.m),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Guest Player',
                  style: NexiraTypography.title.copyWith(
                    color: NexiraColors.textPrimary,
                  ),
                ),
                const SizedBox(height: NexiraSpacing.xs),
                Text(
                  'Level 01 • XP 240',
                  style: NexiraTypography.body.copyWith(
                    color: NexiraColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PrimaryActionCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Ready for the next run?',
            style: NexiraTypography.headline.copyWith(
              color: NexiraColors.textPrimary,
            ),
          ),
          const SizedBox(height: NexiraSpacing.s),
          Text(
            'Enter a fast, neon-lit challenge designed to sharpen your instincts.',
            style: NexiraTypography.body.copyWith(
              color: NexiraColors.textSecondary,
            ),
          ),
          const SizedBox(height: NexiraSpacing.l),
          NeonButton(
            onPressed: () {
              Navigator.of(context).pushNamed(AppRoutes.battle);
            },
            isFullWidth: true,
            child: Text('START CHALLENGE', style: NexiraTypography.label),
          ),
        ],
      ),
    );
  }
}

class _ModeSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final isCompact = MediaQuery.sizeOf(context).width < 640;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Challenge Modes',
          style: NexiraTypography.title.copyWith(
            color: NexiraColors.textPrimary,
          ),
        ),
        const SizedBox(height: NexiraSpacing.m),
        Wrap(
          spacing: NexiraSpacing.m,
          runSpacing: NexiraSpacing.m,
          children: [
            _ModeCard(
              title: 'Quick Challenge',
              subtitle: 'Fast rounds with instant action.',
              accent: NexiraColors.primary,
              width: isCompact ? double.infinity : 220,
            ),
            _ModeCard(
              title: 'Category Battle',
              subtitle: 'Compete through themed problem waves.',
              accent: NexiraColors.accent,
              width: isCompact ? double.infinity : 220,
            ),
            _ModeCard(
              title: '1 vs AI',
              subtitle: 'Coming soon',
              accent: NexiraColors.success,
              width: isCompact ? double.infinity : 220,
            ),
          ],
        ),
      ],
    );
  }
}

class _ModeCard extends StatelessWidget {
  const _ModeCard({
    required this.title,
    required this.subtitle,
    required this.accent,
    required this.width,
  });

  final String title;
  final String subtitle;
  final Color accent;
  final double width;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      width: width,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              borderRadius: NexiraRadius.small as BorderRadius?,
              color: accent,
            ),
          ),
          const SizedBox(height: NexiraSpacing.s),
          Text(
            title,
            style: NexiraTypography.title.copyWith(
              color: NexiraColors.textPrimary,
            ),
          ),
          const SizedBox(height: NexiraSpacing.xs),
          Text(
            subtitle,
            style: NexiraTypography.body.copyWith(
              color: NexiraColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}
