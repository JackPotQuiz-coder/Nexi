import 'package:flutter/foundation.dart';

import '../../core/models/game_session_model.dart';
import '../../core/models/question_model.dart';
import '../../services/question_repository.dart';
import '../../services/storage/local_storage_service.dart';
import 'game_state.dart';

class GameController extends ChangeNotifier {
  GameController({
    required QuestionRepository questionRepository,
    required LocalStorageService storageService,
  })  : _questionRepository = questionRepository,
        _storageService = storageService;

  final QuestionRepository _questionRepository;
  final LocalStorageService _storageService;

  GameState? _state;
  GameSessionModel? _lastSession;
  bool _isLoading = false;
  bool _isSubmitting = false;
  String? _error;

  GameState? get state => _state;
  GameSessionModel? get lastSession => _lastSession;
  bool get isLoading => _isLoading;
  bool get isSubmitting => _isSubmitting;
  String? get error => _error;

  Future<void> startGame({required String categoryId}) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final questions = await _questionRepository.filterByCategory(categoryId);
      _state = GameState(
        currentQuestionIndex: 0,
        questions: questions,
        selectedAnswer: null,
        score: 0,
        correctAnswers: 0,
        wrongAnswers: 0,
        startTime: DateTime.now(),
      );
    } catch (e) {
      _error = 'Unable to load questions locally.';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> submitAnswer(int selectedIndex) async {
    final currentState = _state;
    if (currentState == null || currentState.currentQuestion == null) {
      return;
    }

    final currentQuestion = currentState.currentQuestion!;
    final isCorrect = selectedIndex == currentQuestion.correctAnswerIndex;

    final updatedScore = currentState.score + (isCorrect ? 10 : 0);
    final updatedCorrect = currentState.correctAnswers + (isCorrect ? 1 : 0);
    final updatedWrong = currentState.wrongAnswers + (isCorrect ? 0 : 1);

    final nextIndex = currentState.currentQuestionIndex + 1;

    if (nextIndex >= currentState.questions.length) {
      _state = currentState.copyWith(
        currentQuestionIndex: currentState.questions.length,
        selectedAnswer: currentQuestion.answers[selectedIndex],
        score: updatedScore,
        correctAnswers: updatedCorrect,
        wrongAnswers: updatedWrong,
      );
      await _completeGame();
      return;
    }

    _state = currentState.copyWith(
      currentQuestionIndex: nextIndex,
      selectedAnswer: currentQuestion.answers[selectedIndex],
      score: updatedScore,
      correctAnswers: updatedCorrect,
      wrongAnswers: updatedWrong,
    );
    notifyListeners();
  }

  Future<void> _completeGame() async {
    final currentState = _state;
    if (currentState == null) {
      return;
    }

    _isSubmitting = true;
    notifyListeners();

    try {
      final session = GameSessionModel(
        id: 'session_${DateTime.now().millisecondsSinceEpoch}',
        categoryId: currentState.questions.isNotEmpty
            ? currentState.questions.first.categoryId
            : 'unknown',
        startTime: currentState.startTime,
        endTime: DateTime.now(),
        score: currentState.score,
        correctAnswers: currentState.correctAnswers,
        wrongAnswers: currentState.wrongAnswers,
        earnedXp: currentState.score,
      );
      await _storageService.saveGameSession(session);
      _lastSession = session;
    } finally {
      _isSubmitting = false;
      notifyListeners();
    }
  }
}
