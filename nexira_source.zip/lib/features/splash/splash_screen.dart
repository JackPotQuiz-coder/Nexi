import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../routes/app_routes.dart';
import '../../shared/theme/app_theme.dart';
import '../../shared/theme/colors.dart';
import '../../shared/theme/radius.dart';
import '../../shared/theme/spacing.dart';
import '../../shared/theme/typography.dart';
import '../../shared/widgets/app_background.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/neon_loader.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _logoOpacity;
  late final Animation<double> _logoScale;
  late final Animation<double> _taglineOpacity;
  late final Animation<double> _taglineOffset;
  late final Animation<double> _barProgress;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    );

    _logoOpacity = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.0, 0.55, curve: Curves.easeOutCubic),
    ).drive(Tween<double>(begin: 0.0, end: 1.0));

    _logoScale = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.0, 0.55, curve: Curves.easeOutBack),
    ).drive(Tween<double>(begin: 0.82, end: 1.0));

    _taglineOpacity = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.35, 0.8, curve: Curves.easeOutCubic),
    ).drive(Tween<double>(begin: 0.0, end: 1.0));

    _taglineOffset = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.35, 0.8, curve: Curves.easeOutCubic),
    ).drive(Tween<double>(begin: 18.0, end: 0.0));

    _barProgress = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.65, 1.0, curve: Curves.easeInOutCubic),
    ).drive(Tween<double>(begin: 0.0, end: 1.0));

    _controller.forward();
    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed && mounted) {
        Navigator.of(context).pushReplacementNamed(AppRoutes.home);
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeExtension = Theme.of(context).extension<NexiraThemeData>();
    final primaryColor = themeExtension?.primaryColor ?? NexiraColors.primary;
    final accentColor = themeExtension?.accentColor ?? NexiraColors.accent;
    final textColor =
        themeExtension?.textPrimaryColor ?? NexiraColors.textPrimary;
    final textSecondaryColor =
        themeExtension?.textSecondaryColor ?? NexiraColors.textSecondary;
    final spacing = themeExtension?.spacing ?? NexiraSpacing.m;

    return TunnelBackground(
      child: Scaffold(
        body: AppBackground(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final width = constraints.maxWidth;
              final height = constraints.maxHeight;

              return Stack(
                alignment: Alignment.center,
                children: [
                  ...List.generate(6, (index) {
                    final top = (height * 0.18) + (index * 48.0);
                    final left = (width * 0.16) + (index * 28.0);
                    final offsetX = (index.isEven ? -1 : 1) * (6 + index * 1.4);
                    final offsetY = (index.isEven ? 1 : -1) * (4 + index * 0.8);
                    final progress = _controller.value * 2.2 + index * 0.35;

                    return Positioned(
                      top: top,
                      left: left,
                      child: Transform.translate(
                        offset: Offset(
                          (math.sin(progress) * offsetX),
                          (math.cos(progress) * offsetY),
                        ),
                        child: Container(
                          width: 8 + (index % 3) * 3.0,
                          height: 8 + (index % 3) * 3.0,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: index.isEven ? primaryColor : accentColor,
                            boxShadow: [
                              BoxShadow(
                                color:
                                    (index.isEven ? primaryColor : accentColor)
                                        .withOpacity(0.45),
                                blurRadius: 12,
                                spreadRadius: 0,
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  }),
                  AnimatedBuilder(
                    animation: _controller,
                    builder: (context, _) {
                      return NeonCard(
                        width: 320,
                        padding: EdgeInsets.symmetric(
                          horizontal: spacing * 1.8,
                          vertical: spacing * 2.2,
                        ),
                        borderRadius: NexiraRadius.large,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Transform.scale(
                              scale: _logoScale.value,
                              child: Opacity(
                                opacity: _logoOpacity.value,
                                child: Column(
                                  children: [
                                    Container(
                                      width: 92,
                                      height: 92,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                          color: accentColor.withOpacity(0.55),
                                          width: 1.5,
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                            color: primaryColor.withOpacity(
                                              0.24,
                                            ),
                                            blurRadius: 24,
                                            spreadRadius: 2,
                                          ),
                                        ],
                                      ),
                                      alignment: Alignment.center,
                                      child: Text(
                                        'N',
                                        style: NexiraTypography.headline
                                            .copyWith(
                                              color: textColor,
                                              fontSize: 38,
                                              letterSpacing: 1.6,
                                            ),
                                      ),
                                    ),
                                    SizedBox(height: spacing),
                                    Text(
                                      'NEXIRA',
                                      style: NexiraTypography.title.copyWith(
                                        color: textColor,
                                        letterSpacing: 2.2,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            SizedBox(height: spacing * 1.5),
                            Transform.translate(
                              offset: Offset(0, _taglineOffset.value),
                              child: Opacity(
                                opacity: _taglineOpacity.value,
                                child: Text(
                                  'Challenge Your Mind',
                                  style: NexiraTypography.body.copyWith(
                                    color: textSecondaryColor,
                                    letterSpacing: 0.6,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ),
                            SizedBox(height: spacing * 2.2),
                            Opacity(
                              opacity: _taglineOpacity.value,
                              child: _NeonLoaderCard(
                                progress: _barProgress.value,
                                primaryColor: primaryColor,
                                accentColor: accentColor,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _NeonLoaderCard extends StatelessWidget {
  const _NeonLoaderCard({
    required this.progress,
    required this.primaryColor,
    required this.accentColor,
  });

  final double progress;
  final Color primaryColor;
  final Color accentColor;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        NeonLoader(size: 52),
        const SizedBox(height: NexiraSpacing.s),
        Text(
          'Initializing experience',
          style: NexiraTypography.caption.copyWith(
            color: NexiraColors.textSecondary,
          ),
        ),
      ],
    );
  }
}
