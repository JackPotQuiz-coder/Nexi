class QuestionModel {
  const QuestionModel({
    required this.id,
    required this.categoryId,
    required this.questionText,
    required this.answers,
    required this.correctAnswerIndex,
    required this.difficulty,
    required this.tags,
    this.imageAsset,
  });

  final String id;
  final String categoryId;
  final String questionText;
  final String? imageAsset;
  final List<String> answers;
  final int correctAnswerIndex;
  final String difficulty;
  final List<String> tags;

  factory QuestionModel.fromJson(Map<String, dynamic> json) {
    return QuestionModel(
      id: json['id'] as String,
      categoryId: json['categoryId'] as String,
      questionText: json['questionText'] as String,
      imageAsset: json['imageAsset'] as String?,
      answers: List<String>.from(json['answers'] as List),
      correctAnswerIndex: json['correctAnswerIndex'] as int,
      difficulty: json['difficulty'] as String,
      tags: List<String>.from(json['tags'] as List),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'categoryId': categoryId,
      'questionText': questionText,
      'imageAsset': imageAsset,
      'answers': answers,
      'correctAnswerIndex': correctAnswerIndex,
      'difficulty': difficulty,
      'tags': tags,
    };
  }
}
