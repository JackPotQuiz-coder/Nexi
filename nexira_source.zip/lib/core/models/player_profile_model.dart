class PlayerProfileModel {
  const PlayerProfileModel({
    required this.id,
    required this.displayName,
    required this.avatar,
    required this.xp,
    required this.level,
    required this.gamesPlayed,
    required this.createdAt,
  });

  final String id;
  final String displayName;
  final String avatar;
  final int xp;
  final int level;
  final int gamesPlayed;
  final DateTime createdAt;

  factory PlayerProfileModel.fromJson(Map<String, dynamic> json) {
    return PlayerProfileModel(
      id: json['id'] as String,
      displayName: json['displayName'] as String,
      avatar: json['avatar'] as String,
      xp: json['xp'] as int,
      level: json['level'] as int,
      gamesPlayed: json['gamesPlayed'] as int,
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'displayName': displayName,
      'avatar': avatar,
      'xp': xp,
      'level': level,
      'gamesPlayed': gamesPlayed,
      'createdAt': createdAt.toIso8601String(),
    };
  }
}
